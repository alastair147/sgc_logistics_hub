<?php
/**
 * Created by Chris on 9/29/2014 3:59 PM.
 */

echo 'Where do you think your going?';